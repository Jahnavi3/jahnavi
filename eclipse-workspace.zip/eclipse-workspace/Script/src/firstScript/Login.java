package firstScript;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.WebElement;
public class Login {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Deepika\\Downloads\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://stage.wer4happytails.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		WebElement cookies = driver.findElement(By.id("onetrust-reject-all-handler"));
		cookies.click();
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
		WebElement login = driver.findElement(By.xpath("//a[contains(text(),'Login')]"));
		wait.until(ExpectedConditions.visibilityOf(login));
		login.click();
		WebElement uname = driver.findElement(By.xpath("//input[@id='edit-name']"));
		uname.sendKeys("janocoxe@tutuapp.bid");
		WebElement pwd = driver.findElement(By.xpath("//input[@id='edit-pass']"));
		pwd.sendKeys("Admin@123");
		WebElement button = driver.findElement(By.xpath("//input[@id='edit-submit']"));
		button.click();
		driver.findElement(By.linkText("About Us")).click();
		WebElement findapet = driver.findElement(By.linkText("FIND A PET"));
		wait.until(ExpectedConditions.visibilityOf(findapet));
		findapet.click();
//		WebElement zipcode = driver.findElement(By.xpath("//input[@id='dropdownMenuLink']"));
//		zipcode.sendKeys("2315");
//		WebElement radius = driver.findElement(By.xpath("//span[contains(text(),'RADIUS + KM')]"));
//		radius.click();
//		Actions actions = new Actions(driver);
//		List<WebElement> km = driver.findElements(By.tagName("li"));
//		for (WebElement li : km)
//		{
//			if(li.getText().equals("10 km")) {
//				System.out.print(li.getText());
//				actions.moveToElement(li);
//				actions.click(li).perform();
//			}	
//		}
//		WebElement selectpet = driver.findElement(By.xpath("//span[contains(text(),'SELECT PET (Optional)')]"));
//		selectpet.click();
//		WebElement pet = driver.findElement(By.xpath("//li[contains(text(),'Cat')]"));
//		pet.click();
//		WebElement search = driver.findElement(By.xpath("//input[@id='edit-submit']"));
//		search.click();
		//sleep(6000);
		driver.findElement(By.xpath("//div[@class = 'readmore-position']//a[@href='/pet-details?page=,0']")).click();
		//sleep(3000);
		driver.findElement(By.xpath("//a[contains(text(),'Adopt Me')]")).click();
		driver.findElement(By.xpath("//input[@id='edit-field-date-0-value-date']")).sendKeys("15-02-2024");
		
		//Selecting time using select method
		Select time = new Select(driver.findElement(By.xpath("//select[@id='edit-field-time']")));
		time.selectByValue("04:00");
		
		//using Actions class
//		Actions act = new Actions(driver);
//		List<WebElement> time = driver.findElements(By.tagName("option"));
//		for(WebElement option : time) {
//			if(option.getText().equals("04:00")) {
//				System.out.print(option.getText());
//				act.moveToElement(option);
//				act.click(option).perform();
//			}
//		}
		Select ampm = new Select(driver.findElement(By.xpath("//select[@id='edit-field-ampm']")));
		ampm.selectByVisibleText("PM");
		driver.findElement(By.xpath("//input[@id='edit-field-phone-number-0-value-int-phone']")).sendKeys("09051234567");
		driver.findElement(By.xpath("//input[@id='edit-field-telegram-0-value']")).sendKeys("test");
		WebElement email = driver.findElement(By.xpath("//input[@id='Email']"));
		boolean isSelected = email.isSelected();
		if(isSelected == false) {
			email.click();
		}
		WebElement phone = driver.findElement(By.xpath("//input[@id='Phone']"));
		boolean isDisplayed = phone.isDisplayed();
		if(isDisplayed == true) {
			phone.click();
		}
		WebElement fb = driver.findElement(By.xpath("//input[@id='Facebook/Instagram']"));
		boolean isEnabled = fb.isEnabled();
		if(isEnabled == true) {
			fb.click();
		}
//		JavascriptExecutor js = (JavascriptExecutor)driver;
//		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		sleep(5000);
		
		
		
	}

	private static void sleep(int i) {
		// TODO Auto-generated method stub
		try {
			Thread.sleep(i);
		}
		catch(InterruptedException e) {
			e.printStackTrace();
			
		}
		
	}


}
