package com.sdet;
import java.time.Duration;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;


@Test
public class TC_Login01 {
	public void login() {
		Logger log = LogManager.getLogger(TC_Login01.class);
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://the-internet.herokuapp.com/login");
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("//input[@id='username']")).sendKeys("tomsmth");
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("SuperSecretPassord!");
		driver.findElement(By.xpath("//i[contains(text(),'Login')]")).click();
		
		String actualUrl = "https://the-internet.herokuapp.com/secure";
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(5));
		try {
		Assert.assertEquals(actualUrl, driver.getCurrentUrl());
		}catch(Exception e) {
			log.info("Test case Failed ");
		}
		
		driver.close();
	}

}
