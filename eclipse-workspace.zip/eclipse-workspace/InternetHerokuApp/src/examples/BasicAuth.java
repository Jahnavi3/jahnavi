package examples;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.HasAuthentication;
import org.openqa.selenium.UsernameAndPassword;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BasicAuth {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Deepika\\Downloads\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
//		driver.get("https://the-internet.herokuapp.com/");
//		driver.manage().window().maximize();
//		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
//		WebElement url = driver.findElement(By.xpath("//a[text()='Basic Auth']"));
//		wait.until(ExpectedConditions.visibilityOf(url));
		
		
		HasAuthentication authentication = (HasAuthentication) driver;
		authentication.register(() -> new UsernameAndPassword("admin", "admin"));
		driver.get("https://the-internet.herokuapp.com/basic_auth");
		}
}
//This "HasAuthentication" interface is the key!
//HasAuthentication authentication (HasAuthentication) driver;

//You can either register something for all sites
//authentication.register(() -> new UsernameAndPassword("admin", "admin"));

//Or use something different for specific sites
//authentication.register(
//uri -> uri.getHost().contains("mysite.com"),
//new UsernameAndPassword("AzureDiamond", "hunter2"));
