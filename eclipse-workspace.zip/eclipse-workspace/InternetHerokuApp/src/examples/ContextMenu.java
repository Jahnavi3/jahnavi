package examples;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class ContextMenu {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Deepika\\Downloads\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://the-internet.herokuapp.com/context_menu");
		driver.manage().window().maximize();
		sleep(2000);
		WebElement box = driver.findElement(By.xpath("//div[@id='hot-spot']"));
		Actions act = new Actions(driver);
		act.contextClick(box).perform();
		driver.switchTo().alert().accept();
		
		
		
	}

	private static void sleep(int i) {
		// TODO Auto-generated method stub
		try {
			Thread.sleep(i);
		}
		catch(InterruptedException e) {
			e.printStackTrace();
			
		}
		
	}

}
