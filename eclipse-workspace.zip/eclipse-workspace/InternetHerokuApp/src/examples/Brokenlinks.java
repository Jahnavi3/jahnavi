package examples;

import java.net.URL;
import java.util.List;
import java.net.HttpURLConnection;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Brokenlinks {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Deepika\\Downloads\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://the-internet.herokuapp.com/broken_images");
		driver.manage().window().maximize();
		List<WebElement> l = driver.findElements(By.tagName("img"));// for broken images
		//For broken links
		//List<WebElement> l = driver.findElements(By.tagName("a"));
		
		for(int i=0;i<l.size();i++)
		{
			String u = l.get(i).getAttribute("src");// for broken images
			//For broken links
			//String u = l.get(i).getAttribute("href");
			try {
							
			URL url = new URL(u);
			HttpURLConnection h=(HttpURLConnection)url.openConnection();
			h.setConnectTimeout(5000);
			h.connect();
			if(h.getResponseCode()>=400) {
				System.out.println(url+" is a broken image");
				
			}
			else {
				System.out.println(url+" is a valid image");
			}
		}
			catch(Exception e) {}
	}
	
	}

}
