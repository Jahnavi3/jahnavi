package examples;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CheckBoxes {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Deepika\\Downloads\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://the-internet.herokuapp.com/checkboxes");
		driver.manage().window().maximize();
		//WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(5));
		WebElement cb1 = driver.findElement(By.xpath("//form[@id='checkboxes']/descendant::input[1]"));
		//w.until(ExpectedConditions.visibilityOf(cb1));
		cb1.click();
//		if(cb1.isSelected()==false) {
//			cb1.click();
//			sleep(3000);
//		}
		WebElement cb2 = driver.findElement(By.cssSelector("#checkboxes > input[type=checkbox]:nth-child(3)"));
//		//w.until(ExpectedConditions.visibilityOf(cb2));
		if(cb2.isSelected()==true) {
			System.out.print("Checkbox 2 is preselected");
			cb2.click();
			sleep(3000);
		}
//		if(cb1.isSelected()==true) {
//			cb1.click();
//			sleep(3000);
//		}
	}
	private static void sleep(int i) {
		// TODO Auto-generated method stub
		try {
			Thread.sleep(i);
		}
		catch(InterruptedException e) {
			e.printStackTrace();
			
		}
		
	}

}
