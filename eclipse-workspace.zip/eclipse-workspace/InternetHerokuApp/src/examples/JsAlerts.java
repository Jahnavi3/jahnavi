package examples;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class JsAlerts {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Deepika\\Downloads\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://the-internet.herokuapp.com/javascript_alerts");
		driver.manage().window().maximize();
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
		driver.findElement(By.xpath("//button[contains(text(),'Click for JS Alert')]")).click();
		wait.until(ExpectedConditions.alertIsPresent());
		driver.switchTo().alert().accept();
		System.out.println(driver.findElement(By.xpath("//p[@id='result']")).getText());

		driver.findElement(By.xpath("//button[contains(text(),'Click for JS Confirm')]")).click();
		wait.until(ExpectedConditions.alertIsPresent());
		driver.switchTo().alert().dismiss();
		System.out.println(driver.findElement(By.xpath("//p[@id='result']")).getText());
		
		driver.findElement(By.xpath("//button[contains(text(),'Click for JS Prompt')]")).click();
		wait.until(ExpectedConditions.alertIsPresent());
		driver.switchTo().alert().sendKeys("OK");
		driver.switchTo().alert().accept();
		System.out.println(driver.findElement(By.xpath("//p[@id='result']")).getText());
	}

}
