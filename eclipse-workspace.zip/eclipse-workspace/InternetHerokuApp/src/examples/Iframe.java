package examples;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Iframe {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Deepika\\Downloads\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.letskodeit.com/practice");
		driver.manage().window().maximize();
		//If there is 1 iframe , switching to that iframe
		WebElement iframe = driver.findElement(By.xpath("//iframe[@id='courses-iframe']"));
		driver.switchTo().frame(iframe);
		System.out.print(driver.findElement(By.xpath("//h1[contains(text(),'All Courses')]")).getText());
		//switching to main frame
		driver.switchTo().defaultContent();
		System.out.println(driver.findElement(By.xpath("//h1[contains(text(),'Practice Page')]")).getText());
		
		
	
	}

}
