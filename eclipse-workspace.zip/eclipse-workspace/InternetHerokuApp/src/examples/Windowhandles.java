package examples;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Windowhandles {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Deepika\\Downloads\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.letskodeit.com/practice");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//button[@id='openwindow']")).click();
		//id of windows will be stored in string
		String currentwindow = driver.getWindowHandle();
		Set<String> otherwindows = driver.getWindowHandles();
		Iterator<String> i = otherwindows.iterator();
		while(i.hasNext())
		{
			String nextwindow = i.next();
			if(!currentwindow.equalsIgnoreCase(nextwindow)&& driver.findElement(By.xpath("//button[@id='openwindow']")).isDisplayed()) {
				driver.switchTo().window(nextwindow);
				WebElement heading = driver.findElement(By.xpath("//h1[contains(text(),'All Courses')]"));
				driver.manage().window().maximize();
				System.out.print("Child Window text is "+heading.getText());
				driver.close();
			}
		}
		//driver.switchTo().defaultContent();
		driver.switchTo().window(currentwindow);
		
	}
	
	//File s = ((TakeScreenShot)driver).getScreenshotAs(OutputType.File);
	//FileUtils.copyFile(s, new File("path"));

}
